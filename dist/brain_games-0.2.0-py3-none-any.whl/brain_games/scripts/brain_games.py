import prompt
from brain_games.games.brain_games import welcome_user

def main():
    """
    Основная функция программы.
    """
    welcome_user()

if __name__ == "__main__":
    main()
