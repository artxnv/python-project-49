### Hexlet tests and linter status:
[![Actions Status](https://github.com/artxnv/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/artxnv/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/c4603fac907ec8b89895/maintainability)](https://codeclimate.com/github/artxnv/python-project-49/maintainability)
